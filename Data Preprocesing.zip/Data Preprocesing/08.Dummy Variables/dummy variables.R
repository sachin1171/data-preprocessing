#Dummy Variables
install.packages("readr")
library(readr)
d <- read.csv(file.choose())
summary(d)

install.packages("fastDummies")
library(fastDummies)

dm <- dummy_cols(d, select_columns = c("Animals", "Gender", "Homly", "Types"),
                 remove_first_dummy = TRUE,remove_most_frequent_dummy = FALSE,remove_selected_columns = TRUE)

### Label encoding in R
install.packages("CatEncoders")
library(CatEncoders)
View(d)
# character column: 'Animals'
label <- LabelEncoder.fit(d$Animals)
# new values are transformed to NA
animal_new <- transform(label, d$Animals)
animal_new
# Using cbind to combine with original dataset
newdata <- cbind(d, animal_new)
?`transform,`

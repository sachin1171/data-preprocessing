# Dummy Variable
import pandas as pd
df1 = pd.read_csv("C:/Users/usach/Desktop/DataSets/animal_category.csv")
df1.columns
#drop index col
df1.drop(['Index'], axis = 1, inplace=True)
df1.dtypes
# Create dummy variables on categorical columns
df2 = pd.get_dummies(df1)
####
df3 = pd.read_csv("C:/Users/usach/Desktop/DataSets/animal_category.csv")
from sklearn.preprocessing import LabelEncoder
# creating instance of labelencoder
ln = LabelEncoder()
df3["Animals"] = ln.fit_transform(df3["Animals"])
df3["Gender"] = ln.fit_transform(df3["Gender"])

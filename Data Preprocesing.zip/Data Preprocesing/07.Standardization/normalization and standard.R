#STANDARDIZATION & NORMALIZATION

###NORMALIZATION
install.packages("readr")
data1 <- read.csv(file.choose())
View(data1)

# to normalize the data we use custom function 
norm1 <- function(x){
  return((x - min(x))/(max(x)-min(x)))
}
datanorm <- as.data.frame(lapply(data1, norm1))
# Normalized data have values ranging between 0 to 1

#STANDARDIZATION
# To apply standardization we have inbuilt function scale
data2 <- read.csv(file.choose())
View(data2)
# use scale function 
data2scale <- as.data.frame(scale(data2))
# hypothetically you have values ranging between -3 to +3 or in general the range is -inf to +inf
#Normalization
import pandas as pd
import numpy as np
df = pd.read_csv("C:/Users/usach/Desktop/DataSets/Seeds_data.csv")

# Normalization function using z std. all are continuous data.
def norm_func(i):
    x = (i-i.mean())/(i.std())
    return (x)
# Normalized data frame (considering the numerical part of data)
df_norm = norm_func(df.iloc[:,0:7])
df_norm.describe()

################## Type casting###############################################

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
data = pd.read_csv('C:/Users/usach/Desktop/DataSets/OnlineRetail.csv', engine='python')
data.dtypes

#type casting
# Now we will convert 'float64' into 'int64' type. 
data.Quantity = data.Quantity.astype('int64') 
data.dtypes


#Identify duplicates records in the data
duplicate = data.duplicated()
sum(duplicate)

#Removing Duplicates
data1 = data.drop_duplicates() 

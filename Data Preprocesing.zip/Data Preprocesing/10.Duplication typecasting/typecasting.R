###################### Type Casting ########################
# Type casting is used to convert one data type into another.
# ex: categorical data to numeric data
install.packages("readr")
library(readr)

data1 <- read.csv(file.choose())
View(data1)
as.numeric(data1$Quantity) 

is.numeric(data1$Quantity) # it will return true or false
str(data1)

# Ex: Convert Numeric to Integer
data1$Quantity <- as.integer(data1$Quantity)

dup1 <- duplicated(data1)
dup1
data1_new <- data1[!duplicated(data1), ]
data1_new

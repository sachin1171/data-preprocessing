####################################################################
# Question.5
#solution
#load data set
install.packages("readxl")
library(readxl)
a1 <- read_excel(file.choose(),sheet = 1)
attach(a1)
mean(a1$Points)
mean(a1$Score)
mean(a1$Weigh)
median(a1$Points)
median(a1$Score)
median(a1$Weigh)
var(a1$Points)
var(a1$Score)
var(a1$Weigh)
sd(a1$Points)
sd(a1$Score)
sd(a1$Weigh)
range(a1$Points)
range(a1$Score)
range(a1$Weigh)
#############################################################################3
#Question.7
#solution
#load data set
a <- read_excel(file.choose(),sheet = 1)
attach(a)
mean(a$`Measure X`)
var(a$`Measure X`)
sd(a$`Measure X`)
hist(a$`Measure X`)
boxplot(a$`Measure X`) # atleast one outlier present in data
library(moments)
skewness(a$`Measure X`) # right skewed

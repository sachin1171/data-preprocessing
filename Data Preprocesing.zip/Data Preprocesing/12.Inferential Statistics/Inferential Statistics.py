###################################################################
#Question.7
#Solution
import pandas as pd
import numpy as np
from scipy.stats import stats
import matplotlib.pyplot as plt
import seaborn as sn
from scipy.stats import iqr
from scipy.stats import skew
a=[24.23,25.53,25.41,24.14,29.62,28.25,25.81,24.39,40.26,32.95,91.36,25.99,39.42,26.71,35.00]
df=pd.DataFrame(a,columns=["Measure X"])
df.describe()
print(df.var(),df.mode())
sn.boxplot(df["Measure X"])
sn.kdeplot(df["Measure X"])
iqr(df)
#############################################################
#Question 5
#solution
import pandas as pd
import numpy as np
from scipy.stats import stats
data=pd.read_excel("C:/Users/usach/Desktop/DataSets/Assignment_module02 (1).xlsx")
data.head(5)
data.describe()
data.var()
data.mode()
stats.describe(data)
pd.DataFrame(data).skew()[0]

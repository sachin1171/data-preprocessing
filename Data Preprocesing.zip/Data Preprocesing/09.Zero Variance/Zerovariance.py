#Zero variance
import pandas as pd
from statistics import variance as var

df = pd.read_csv("C:/Users/usach/Desktop/DataSets/Z_dataset.csv")
df.columns

#checking for variance of each column of df_dataset using for loop except last column which contains strings
for i in range(0,len(df.columns)-1):
    print(df.columns[i],'var =',var(df.iloc[ :, i]))

#checking for variance of each column of df_dataset using apply function except last column which contains strings
df.iloc[:,0:5].apply(var)


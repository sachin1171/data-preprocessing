#Zero - variance
data1 <- read.csv(file.choose())
library(ggplot2)
install.packages('ggthemes', dependencies = TRUE)
library(ggthemes)
# Use 'apply' and 'var' functions to 
# check for variance on numerical values
apply(data1, 2, var)
# Check for the columns having zero variance
#Discritization
import pandas as pd
df = pd.read_csv("C:/Users/usach/Desktop/DataSets/iris.csv")
df1 = df.copy()
df1.columns
for i in range(1,len(df.columns)-1):
    print(df.iloc[ :,i].name)
    df.iloc[ :,i] = pd.qcut(df.iloc[ :,i], q=5, precision = 3, duplicates= 'drop')
    
df1.head()    
df1.tail()    
#Grouping
df2 = df.copy()

df2_grouped = df1.iloc[ :,1:].groupby('Species').sum()

df2_grouped

data <- read.csv(file.choose())
data("iris") # taken inbuilt data set
### convert continuous variables into categories
# based on sepal.length
a <- cut(iris$Sepal.Length, breaks = c(4.3, 5.4,6.1, 7.9),labels = c("setosa
                                                                     ","versicolor","virginica"), right = F)
print(a)


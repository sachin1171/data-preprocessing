#Outlier Treatments
install.packages("readr")
library(readr)
b <- read.csv(file.choose())
b1 <- b
sum(is.na(b))
View(b)
summary(b)
boxplot(b)
#################################################################
#Outlier treatment for crim
boxplot(b$crim)$out
sum(is.na(b$crim))
?quantile

q1 <- quantile(b$crim, probs = c(.25,.75))
q1
c1 <- quantile(b$crim, probs = c(0,0.89), na.rm = T)
c1
H <- 1.5*IQR( b$crim,na.rm = T)
H 
b$crim[b$crim>(q1[2]+H)] <- c1[2]
boxplot(b$crim)$out
#################################################################
#Outlier treatment for zn
boxplot(b$zn)$out
sum(is.na(b$zn))
q2 <- quantile(b$zn, probs = c(.25,.75))
q2
c2 <- quantile(b$zn, probs= c(0,0.87), na.rm = T)
c2
H1 <- 1.5*IQR( b$zn,na.rm = T)
H1 
b$zn[b$zn>(q2[2]+H1)] <- c2[2]
boxplot(b$zn)$out
##########################################################

boxplot(b$indus)# no outliers
boxplot(b$chas) # only zeros and ones in this column
boxplot(b$nox) # no outlier
##############################################
#Outlier treatment for rm
boxplot(b$rm)$out
q3 <- quantile(b$rm, probs = c(.25,.75))
q3
c3 <- quantile(b$rm, probs =c(0.08,0.92), na.rm = T)
c3
H3 <- 1.5*IQR( b$rm,na.rm = T)
H3 
b$rm[b$rm<(q3[1]-H3)] <- c3[1]
b$rm[b$rm>(q3[2]+H3)] <- c3[2]
boxplot(b$rm)$out

#####################################################################
boxplot(b$age)#no outlier
#############################################
#outlier treatment for dis
boxplot(b$dis)$out
q4 <- quantile(b$dis, probs = c(.25,.75))
q4
c4 <- quantile(b$dis, probs =c(0.04,0.96), na.rm = T)
c4
H4 <- 1.5*IQR( b$dis,na.rm = T)
H4 
b$dis[b$dis<(q4[1]-H4)] <- c4[1]
b$dis[b$dis>(q4[2]+H4)] <- c4[2]
boxplot(b$dis)$out

#################################################################
boxplot(b$rad)#no outlier
boxplot(b$tax)#no outlier
#######################################################
#outlier treatment for ptratio
boxplot(b$ptratio)$out

q5 <- quantile(b$ptratio, probs = c(.25,.75))
q5
c5 <- quantile(b$ptratio, probs =c(0.06,0), na.rm = T)
c5
H5 <- 1.5*IQR( b$ptratio,na.rm = T)
H5 
b$ptratio[b$ptratio<(q5[1]-H5)] <- c5[1]
b$ptratio[b$ptratio>(q5[2]+H5)] <- c5[2]
boxplot(b$ptratio)$out
################################################################
#outlier treatment for black

boxplot(b$black)$out
q7 <- quantile(b$black, probs = c(.25,.75))
q7
c7 <- quantile(b$black, probs =c(0.32,0), na.rm = T)
c7
H7 <- 1.5*IQR( b$black,na.rm = T)
H7 
b$black[b$black<(q7[1]-H7)] <- c7[1]
boxplot(b$black)$out
##################################################################
#outlier treatment for lstat
boxplot(b$lstat)$out

q8 <- quantile(b$lstat, probs = c(.25,.75))
q8
c8 <- quantile(b$lstat, probs =c(0.02,0.98), na.rm = T)
c8
H8 <- 1.5*IQR( b$lstat,na.rm = T)
H8 
b$lstat[b$lstatk<(q8[1]-H8)] <- c8[1]
b$lstat[b$lstat>(q8[2]+H8)] <- c8[2]
boxplot(b$lstat)$out
########################################################################
#outlier treatment for medv
boxplot(b$medv)$out
q9 <- quantile(b$medv, probs = c(.25,.75))
q9
c9 <- quantile(b$medv, probs =c(0.14,0.86), na.rm = T)
c9
H9 <- 1.5*IQR( b$medv,na.rm = T)
H9 
b$medv[b$medv<(q9[1]-H9)] <- c9[1]
b$medv[b$medv>(q9[2]+H9)] <- c9[2]
boxplot(b$medv)$out
## Missing values - imputation
install.packages("readr")
library(readr)
c <- read.csv(file.choose())
View(c)
dim(c) #1340 rows, 7col
summary(c)
attach(c)
sum(is.na(c)) #290
# Omitting NA values from the Data
domit <- na.omit(c) # # na.omit => will omit the rows which has atleast 1 NA value
dim(domit) # 1096 rows, 7 col
sum(is.na(domit)) #0
boxplot(domit$CASENUM)$out # at least 29 outliers in data 
# for column 1 we can apply median imputaion
n1 <- c
n1$CASENUM[is.na(n1$CASENUM)] <- median(n1$CASENUM, na.rm = TRUE)

##################################################################
boxplot(n1$ATTORNEY)$out # no outliers
# we can apply mean imputation
n1$ATTORNEY[is.na(n1$ATTORNEY)] <- mean(n1$ATTORNEY, na.rm = TRUE)
sum(is.na(n1$ATTORNEY))

###################################################################
boxplot(n1$CLMSEX)$out
sum(is.na(n1$CLMSEX))# 8 NA values 
n1$CLMSEX[is.na(n1$CLMSEX)] <- mean(n1$CLMSEX, na.rm = TRUE)
sum(is.na(n1$CLMSEX))# no NA values

########################################
boxplot(n1$CLMINSUR)$out
sum(is.na(n1$CLMINSUR))
n1$CLMINSUR[is.na(n1$CLMINSUR)] <- median(n1$CLMINSUR, na.rm = TRUE)
sum(is.na(n1$CLMINSUR))

###############################################################
boxplot(n1$SEATBELT)$out # outliers exist
sum(is.na(n1$SEATBELT))#48 NA values
#we can apply median imputation
n1$SEATBELT[is.na(n1$SEATBELT)] <- median(n1$SEATBELT, na.rm = TRUE)
sum(is.na(n1$SEATBELT)) # zero NA values

#########################################################
boxplot(n1$CLMAGE)$out # one outlier present in data
sum(is.na(n1$CLMAGE)) # 189 NA values
n1$CLMAGE[is.na(n1$CLMAGE)] <- median(n1$CLMAGE, na.rm = TRUE)
sum(is.na(n1$CLMAGE)) # zero NA values

###############################################################
boxplot(n1$LOSS)$out
sum(is.na(n1$LOSS))# no NA values in data


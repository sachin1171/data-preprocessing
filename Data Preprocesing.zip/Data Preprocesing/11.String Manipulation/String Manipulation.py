###################STRING MANIPULATIONS###########################
#Question1
#Solution
w = "Grow Gratitude"
print(w)
##Accessing
word ="Growth"
letter=word[0]
#length 
len(w) # length 14
len(word) # length 6
#finding
print(w.count('G')) # 2 times

########################################################################
#Question2
s1 = "Being aware of a single shortcoming within yourself is far more useful than being aware of a thousand in someone else."
print(s1.count(' '))


########################################################################
#Question3.Create a string "Idealistic as it may sound, altruism should be the driving force in business, not just competition and a desire for wealth"
#Solution

#Slicing
s2 = "Idealistic as it may sound, altruism should be the driving force in business, not just competition and a desire for wealth"
print (s2[0]) #get one char of the word
print (s2[0:1]) #get one char of the word
print (s2[0:3]) #get the first three char
print (s2[:3]) #get the first three char
print (s2[-3:]) #get the last three char

###########################################################################
#Question4.create a string "stay positive and optimistic". Now write a code to split on whitespace.
#Solution
# spliting
w3 = "stay positive and optimistic"
w3.split(' ') # Split on whitespace
# Startswith / Endswith
w3.startswith("H") # False
w3.endswith("d") # False
w3.endswith("c") #True
######################################################
#Question5.Write a code to print " 🪐 " one hundred and eight times. (only in python)
#Solution
# repeat string 

print( " 🪐 "* 108 )# prints 108 times




#####################################################################
#Question7.Create a string “Grow Gratitude” and write a code to replace “Grow” with “Growth of”
#Solution
# replacing

w4 = "Grow Gratitude"

w4.replace("Grow", "Growth of")


########################################
#Question8.
#Solution
s3 = "elgnujehtotniffo deps mehtfohtoB .eerfnoilehttesotseporeht no dewangdnanar eh ,ylkciuQ .elbuortninoilehtdecitondnatsapdeklawesuomeht ,nooS .repmihwotdetratsdnatuotegotgnilggurts saw noilehT .eert a tsniagapumihdeityehT .mehthtiwnoilehtkootdnatserofehtotniemacsretnuhwef a ,yad enO .ogmihteldnaecnedifnocs’esuomeht ta dehgualnoilehT ”.emevasuoy fi yademosuoyotplehtaergfo eb lliw I ,uoyesimorp I“ .eerfmihtesotnoilehtdetseuqeryletarepsedesuomehtnehwesuomehttaeottuoba saw eH .yrgnaetiuqpuekow eh dna ,peels s’noilehtdebrutsidsihT .nufroftsujydobsihnwoddnapugninnurdetratsesuom a nehwelgnujehtnignipeelsecno saw noil A"
print (''.join(reversed(s3)))





#Transformation
import pandas as pd
import scipy.stats as stats
import pylab
import numpy as np

df = pd.read_csv("C:/Users/usach/Desktop/DataSets/calories_consumed.csv")
df.columns
# Checking Whether data is normally distributed
stats.probplot(df['Weight gained (grams)'], dist="norm",plot=pylab)

stats.probplot(df['Calories Consumed'],dist="norm",plot=pylab)

stats.probplot(np.log(df['Weight gained (grams)']),dist="norm",plot=pylab)
stats.probplot(np.log(df['Calories Consumed']),dist="norm",plot=pylab)

 

#Transformation
install.packages("readr")
library(readr)
a1 <- read.csv(file.choose())
summary(a1)
class(a1)
attach(a1)
hist(Weight.gained..grams.)
hist(a1$`Weight.gained..grams.`)
hist(log(a1$`Weight.gained..grams.`)) # more symmetrical
hist(sqrt(a1$`Weight.gained..grams.`)) # symmetrical
hist(exp(a1$`Weight.gained..grams.`)) # more symetrical
hist(1/a1$`Weight.gained..grams.`) # symmetrical
############################################
hist(a1$`Calories.Consumed`)
hist(log(a1$`Calories.Consumed`)) # more symmetrical
hist(sqrt(a1$`Calories.Consumed`)) # symmetrical
hist(exp(a1$Calories.Consumed)) # more symetrical
hist(1/a1$`Calories Consumed`) # symmetrical
